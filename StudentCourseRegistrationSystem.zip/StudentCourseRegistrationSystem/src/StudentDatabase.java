import java.util.*;

public class StudentDatabase {
    public List<Student> students = new ArrayList<>();

    public StudentDatabase() {
        students.add(new Student("727724EUCS517", "Sarvesh T"));
        students.add(new Student("727723EUCS215", "Student1"));
        students.add(new Student("727723EUCS216", "Student2"));
        students.add(new Student("727723EUCS217", "Student3"));
        students.add(new Student("727723EUCS218", "Student4"));
        students.add(new Student("727723EUCS219", "Student5"));
        students.add(new Student("727723EUCS220", "Student6"));
        students.add(new Student("727723EUCS221", "Student7"));
        students.add(new Student("727723EUCS222", "Student8"));
        students.add(new Student("727723EUCS223", "Student9"));
        students.add(new Student("727723EUCS224", "Student10"));
    }

    public Student getById(String id) {
        for (Student s : students)
            if (s.id.equals(id))
                return s;
        return null;
    }
}
