import java.util.*;

public class Student {
    public String id, name;
    public List<Course> registeredCourses = new ArrayList<>();

    public Student(String id, String name) {
        this.id = id;
        this.name = name;
    }

    public boolean register(Course c) {
        if (!registeredCourses.contains(c) && c.isAvailable()) {
            registeredCourses.add(c);
            c.enroll();
            return true;
        }
        return false;
    }

    public boolean drop(String courseCode) {
        for (Course c : registeredCourses) {
            if (c.code.equals(courseCode)) {
                registeredCourses.remove(c);
                c.drop();
                return true;
            }
        }
        return false;
    }

    public List<Course> getCourses() {
        return registeredCourses;
    }
}
