import java.util.*;

public class CourseDatabase {
    public List<Course> courses = new ArrayList<>();

    public CourseDatabase() {
    	courses.add(new Course("CSE101", "Java Programming", "Basics of Java", 3, "Mon 9-11"));
        courses.add(new Course("MAT201", "Calculus", "Differential equations", 2, "Tue 10-12"));
        courses.add(new Course("PHY301", "Physics", "Mechanics and Waves", 2, "Wed 1-3"));
        courses.add(new Course("CHE101", "Chemistry", "Organic & Inorganic", 3, "Thu 9-11"));
        courses.add(new Course("BIO110", "Biology", "Cell and Molecular Biology", 2, "Fri 2-4"));
        courses.add(new Course("ENG102", "English", "Grammar & Composition", 4, "Mon 1-3"));
        courses.add(new Course("HIS103", "History", "Modern Indian History", 2, "Tue 1-3"));
        courses.add(new Course("ECO104", "Economics", "Micro & Macro Economics", 3, "Wed 10-12"));
        courses.add(new Course("CSE202", "Data Structures", "Stacks, Queues, Trees", 3, "Thu 2-4"));
        courses.add(new Course("CSE303", "Database Systems", "SQL and ER Models", 2, "Fri 10-12"));
    }

    public List<Course> getAllCourses() {
        return courses;
    }

    public Course getByCode(String code) {
        for (Course c : courses)
            if (c.code.equals(code))
                return c;
        return null;
    }
}
