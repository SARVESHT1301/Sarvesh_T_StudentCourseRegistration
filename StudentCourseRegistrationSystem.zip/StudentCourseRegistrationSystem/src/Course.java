public class Course {
    public String code, title, description, schedule;
    public int capacity, enrolled;

    public Course(String code, String title, String description, int capacity, String schedule) {
        this.code = code;
        this.title = title;
        this.description = description;
        this.capacity = capacity;
        this.schedule = schedule;
        this.enrolled = 0;
    }

    public boolean isAvailable() {
        return enrolled < capacity;
    }

    public void enroll() {
        enrolled++;
    }

    public void drop() {
        enrolled--;
    }

    public String toString() {
        return code + " - " + title + " | " + schedule + " | Slots Left: " + (capacity - enrolled);
    }
}
