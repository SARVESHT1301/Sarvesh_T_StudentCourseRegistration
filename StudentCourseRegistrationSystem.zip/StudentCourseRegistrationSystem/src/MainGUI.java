import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainGUI extends JFrame {
    CourseDatabase courseDB = new CourseDatabase();
    StudentDatabase studentDB = new StudentDatabase();
    Student currentStudent;

    JComboBox<String> courseList;
    JTextArea registeredArea;
    JPanel mainPanel;

    public MainGUI() {
        setTitle("Student Course Registration");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center on screen
        setResizable(false);

        showLoginPanel();

        setVisible(true);
    }

    void showLoginPanel() {
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridBagLayout());
        mainPanel.setBackground(new Color(51, 153, 255)); // Light Blue

        JLabel title = new JLabel("STUDENT LOGIN");
        title.setFont(new Font("Arial", Font.BOLD, 24));
        title.setForeground(Color.WHITE);

        JLabel prompt = new JLabel("Enter Student ID:");
        prompt.setForeground(Color.WHITE);
        JTextField idField = new JTextField(15);
        JButton loginBtn = new JButton("LOGIN");
        loginBtn.setBackground(new Color(255, 255, 153)); // Yellow

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridy = 0;
        mainPanel.add(title, gbc);

        gbc.gridy = 1;
        mainPanel.add(prompt, gbc);

        gbc.gridy = 2;
        mainPanel.add(idField, gbc);

        gbc.gridy = 3;
        mainPanel.add(loginBtn, gbc);

        getContentPane().removeAll();
        getContentPane().add(mainPanel);
        revalidate();
        repaint();

        loginBtn.addActionListener(e -> {
            String id = idField.getText().trim();
            currentStudent = studentDB.getById(id);
            if (currentStudent != null) {
                showCoursePanel();
                JOptionPane.showMessageDialog(this, "Welcome " + currentStudent.name);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Student ID");
            }
        });
    }

    void showCoursePanel() {
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        mainPanel.setBackground(new Color(240, 248, 255)); // Alice Blue

        JLabel welcome = new JLabel("Welcome, " + currentStudent.name);
        welcome.setFont(new Font("Arial", Font.BOLD, 18));
        welcome.setHorizontalAlignment(SwingConstants.CENTER);
        welcome.setOpaque(true);
        welcome.setBackground(new Color(135, 206, 250)); // Sky Blue

        JPanel coursePanel = new JPanel();
        coursePanel.setLayout(new GridLayout(6, 1, 10, 10));
        coursePanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
        coursePanel.setBackground(new Color(240, 248, 255));

        courseList = new JComboBox<>();
        updateCourses();

        JButton registerBtn = new JButton("Register Course");
        JButton dropBtn = new JButton("Drop Course");
        JButton finishBtn = new JButton("Finish");
        JButton logoutBtn = new JButton("Logout");

        registerBtn.setBackground(new Color(144, 238, 144)); // Light Green
        dropBtn.setBackground(new Color(255, 160, 122)); // Light Salmon
        finishBtn.setBackground(new Color(173, 216, 230)); // Light Blue
        logoutBtn.setBackground(new Color(255, 222, 173)); // Navajo White

        coursePanel.add(new JLabel("Select Course:"));
        coursePanel.add(courseList);
        coursePanel.add(registerBtn);
        coursePanel.add(dropBtn);
        coursePanel.add(finishBtn);
        coursePanel.add(logoutBtn);

        registeredArea = new JTextArea(8, 40);
        registeredArea.setEditable(false);
        registeredArea.setBackground(new Color(255, 255, 240)); // Ivory
        JScrollPane scrollPane = new JScrollPane(registeredArea);
        updateRegistered();

        mainPanel.add(welcome, BorderLayout.NORTH);
        mainPanel.add(coursePanel, BorderLayout.CENTER);
        mainPanel.add(scrollPane, BorderLayout.SOUTH);

        getContentPane().removeAll();
        getContentPane().add(mainPanel);
        revalidate();
        repaint();

        registerBtn.addActionListener(e -> {
            String courseCode = ((String) courseList.getSelectedItem()).split(" ")[0];
            Course c = courseDB.getByCode(courseCode);
            if (currentStudent.register(c)) {
                JOptionPane.showMessageDialog(this, "Registered: " + c.title);
            } else {
                JOptionPane.showMessageDialog(this, "Could not register. Course full or already added.");
            }
            updateCourses();
            updateRegistered();
        });

        dropBtn.addActionListener(e -> {
            String courseCode = ((String) courseList.getSelectedItem()).split(" ")[0];
            if (currentStudent.drop(courseCode)) {
                JOptionPane.showMessageDialog(this, "Dropped: " + courseCode);
            } else {
                JOptionPane.showMessageDialog(this, "Not found in your registered courses.");
            }
            updateCourses();
            updateRegistered();
        });

        finishBtn.addActionListener(e -> {
            StringBuilder summary = new StringBuilder();
            summary.append("Student ID: ").append(currentStudent.id).append("\n");
            summary.append("Student Name: ").append(currentStudent.name).append("\n\n");
            summary.append("Enrolled Courses:\n");

            if (currentStudent.getCourses().isEmpty()) {
                summary.append("None\n");
            } else {
                for (Course c : currentStudent.getCourses()) {
                    summary.append("- ").append(c.code).append(": ").append(c.title).append("\n");
                }
            }

            JOptionPane.showMessageDialog(this, summary.toString(), "Registration Summary", JOptionPane.INFORMATION_MESSAGE);
            // No logout here; student must manually click Logout
        });

        logoutBtn.addActionListener(e -> showLoginPanel());
    }

    void updateCourses() {
        courseList.removeAllItems();
        for (Course c : courseDB.getAllCourses()) {
            courseList.addItem(c.toString());
        }
    }

    void updateRegistered() {
        registeredArea.setText("Registered Courses:\n");
        for (Course c : currentStudent.getCourses()) {
            registeredArea.append(c.toString() + "\n");
        }
    }

    public static void main(String[] args) {
        new MainGUI();
    }
}
